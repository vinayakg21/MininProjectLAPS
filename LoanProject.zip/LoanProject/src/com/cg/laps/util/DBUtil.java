package com.cg.laps.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import com.cg.laps.exception.LAPSException;

public class DBUtil {
	
	private static Connection conn;
	public static Connection getConnection() throws LAPSException {
		if(conn == null) {
			Properties props = new Properties();
			String path = "./resourse/database.properties";
			
			InputStream res = null;
			try {
				res = new FileInputStream(path);
				props.load(res);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				throw new LAPSException("Properties file missing"+e.getMessage());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				throw new LAPSException("Problem in reading properties"+e.getMessage());
			}
			
			String driver = props.getProperty("db.driver");
			String url = props.getProperty("db.url");
			String user = props.getProperty("db.user");
			String pass = props.getProperty("db.password");
			
			try {
				Class.forName(driver);
				conn = DriverManager.getConnection(url, user, pass);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw new LAPSException("Driver class not found"+e.getMessage());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new LAPSException("Problem in establishing the connection"+e.getMessage());
			}		
			
		}
		System.out.println("Database connection established successsfully");
		return conn;	
	}
	
}