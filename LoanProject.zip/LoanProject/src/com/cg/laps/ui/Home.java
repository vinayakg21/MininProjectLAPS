package com.cg.laps.ui;

import java.util.Scanner;

import com.cg.laps.exception.LAPSException;

public class Home {

	//static LoanManagementService lService=null;
	static Scanner sc=null;
	
	public static void main(String[] args) {
		
		//lService= new LoanManagementServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		System.out.println("***********Welcome to Loan Application Processing System***********");
		while(true)
		{
			System.out.println("Select User Type:");
			System.out.println("1. Admin \n2. Customer \n3. LAD  \n4. Exit");
			System.out.println("Enter your choice:");
			choice=sc.nextInt();
			switch(choice)
			{
				case 1: 
					AdminHome adhome = new AdminHome();
					try {
						adhome.AdminHomeMenu();
					} catch (LAPSException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}					
					break;
					
				case 2:
					CustomerHome chome = new CustomerHome();
					try {
						chome.customerMenu();
					} catch (LAPSException e) {
						// TODO Auto-generated catch block
						System.out.println("Can't open Customer Home"+e.getMessage());
					}					
					break;
					
				case 3:
					LADHome ladhome = new LADHome();
					try {
						ladhome.LADHomeMethod();
					} catch (LAPSException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}					
					break;
					
				default :
					System.exit(0);	
			}//end of the switch
			
		}//end of the while		

	}//end of the main

}//end of the Home class
