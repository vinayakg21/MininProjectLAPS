package com.cg.laps.ui;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.laps.beans.ApprovedLoans;
import com.cg.laps.beans.CustomerDetails;
import com.cg.laps.beans.LoanApplication;
import com.cg.laps.beans.LoanProgramsOffered;
import com.cg.laps.exception.LAPSException;
import com.cg.laps.service.LAPSServicEImpl;
import com.cg.laps.service.LAPSService;



public class LADHome {
	
	Scanner sc = new Scanner(System.in);
	LAPSService lService=null;
	ArrayList<LoanApplication> loanList=null;
	LoanApplication la = null;
	LoanProgramsOffered lpo = null;
	CustomerDetails cd = null;
	String cdname;

	
	public void LADHomeMethod() throws LAPSException{
		
		lService = new LAPSServicEImpl();
		System.out.println("\n***********LAD Login Page***********");
		System.out.println("Enter your login id:");
		String uname=sc.next();
		System.out.println("Enter your password:");
		String pwd=sc.next();
		String role="LAD";
		
		try {
			int value = lService.login(uname,pwd,role);
			if(value == 2)
			{
				System.out.println("Wrong Credentials.Please try again");
			}
			if(value == 1)
			{
				int c=0;
								
				while(c!=5)
				{	
					System.out.println("Select Operation to be performed:");
					System.out.println("1)View all loan Programs \n"
							+ "2)View all Application by loan Programs \n"
							+ "3)Update Application status \n"
							+ "4)Update status after interview \n"
							+ "5)Exit ");
					System.out.println("Enter your choice:");
					c=sc.nextInt();
					switch(c)
					{
						case 1:displayAllLoans();
							break;
						case 2:viewAppByLoanProg();
							break;
						case 3:updateApplicationStatusAndDateUi();
							break;
						case 4:changeStatusAfterInterviewUi();
							break;
						case 5: 
							break;
						default:
								System.out.println("Wrong Choice");
								break;
					}
					
				}	
				
			}
			
		} 
		catch (LAPSException e)
		{
			System.out.println("Wrong credentials.Please retry."+e.getMessage());
		}
	}
	
	private void viewAppByLoanProg() throws LAPSException 
	{
		
		System.out.println("Enter the loan program name to view applications:");
		String progName=sc.next();
		try {
			loanList=lService.viewApplicationByLoanProgram(progName);
			for(LoanApplication l:loanList)
			{
				System.out.println(l);
			}
		}
		catch (LAPSException e) 
		{
			
			System.out.println("Please enter the correct loan program"+e.getMessage());
		}
		
	}
	
	private void displayAllLoans() throws LAPSException 
	{
		
		ArrayList<LoanProgramsOffered> loanList;
		try {
			loanList=lService.viewLoanProgramOffered();
			for(LoanProgramsOffered l:loanList)
			{
				System.out.println(l);
			} 
			
		}
		catch (LAPSException e) {
			
				System.out.println("Sorry for the inconvenience"+e.getMessage());
		}
	}
	


	private void changeStatusAfterInterviewUi() throws LAPSException 
	{
		ApprovedLoans al =null;
		try
		{
			System.out.println("Enter the application Id of the application");
			int id = sc.nextInt();
			la = lService.viewApplicationStatusById(id);
			lpo = lService.getLoanProgramByName(la.getLoanProgram());
			cdname = lService.getCustomerDetailsByAppId(id);
			System.out.println("The application details are");
			System.out.println();
			System.out.println(la);
			if(la.getStatus().equals("approved"))
					{
						System.out.println();
						System.out.println("This application has already been accepted");
						System.out.println();
					}
			else
			{
			System.out.println("Please set the new status as approved or rejected");
			String newStatus= sc.next();
			
			
			int data = lService.setStatusAfterInterview(id, newStatus);
			if(data==1)
				System.out.println("Status is successfully updated");
			
			if(data==1 && newStatus.equals("approved"))
			{
				System.out.println(cdname);
				String custName = cdname;
				System.out.println("Please enter the sum to be granted to the applicant");
				double amtGranted = sc.nextDouble();
				double interest = lpo.getRateOfInterest();
				System.out.println("Enter the dowm payment amount");
				double downPayment = sc.nextDouble();
				int duration = lpo.getDurationInYears();
				double totalAmtPayable = amtGranted + (amtGranted*interest*duration/100);
				double installments = (totalAmtPayable - downPayment)/(duration*12);
				
				al = new ApprovedLoans(id,custName,amtGranted,installments,interest,totalAmtPayable);
				int data1 = lService.addToApprovedLoan(al);
				
				if(data1 == 1)
				{
					System.out.println("The loan has been approved and added to the required database");
				}
			}
			}
		}
		catch(Exception e)
		{
			throw new LAPSException("Please enter the correct status");
		}
	}

	private void updateApplicationStatusAndDateUi() throws LAPSException 
	{
		Date sqlDate;
		try
		{
			
			System.out.println("Enter the application Id of the application");
			int id = sc.nextInt();
			LoanApplication la = lService.viewApplicationStatusById(id);
			System.out.println("The application details are");
			System.out.println(la);
		
			if(la.getStatus().equals("approved") || la.getStatus().equals("accepted"))
			{
				System.out.println("Applroval has already been performed");
				
			}
			else
			{
				LocalDate ldate = null;
				System.out.println("Please set the new status are accepted or rejected");
				String newStatus= sc.next();
				if(newStatus.equals("accepted"))
				{
					System.out.println("Enter the date of interview");
					String sdate = sc.next();
					DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
					ldate = LocalDate.parse(sdate,format);
				}
				else 
				{
					sqlDate = null;
				}
				int data = lService.updateApplicationStatus(id, newStatus, ldate);
				if(data==1)
				System.out.println("Status and date are successfully updated");
			}
		}
		catch(Exception e)
		{
			throw new LAPSException("Please enter the correct status"+e.getMessage());
		}
		
	}

}
