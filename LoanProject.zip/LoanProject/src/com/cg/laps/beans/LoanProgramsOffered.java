package com.cg.laps.beans;

public class LoanProgramsOffered {

	String programName;
	String description; 
	String type;
	int durationInYears;
	double minLoanAmount;
	double maxLoanAmount;
	double rateOfInterest;
	String proofsRequired;
	
	//default constructor
	public LoanProgramsOffered() {
		// TODO Auto-generated constructor stub
	}

	//Parameterized Constructor
	public LoanProgramsOffered(String programName, String description, String type, int durationInYears,
			double minLoanAmount, double maxLoanAmount, double rateOfInterest, String proofsRequired) {
		super();
		this.programName = programName;
		this.description = description;
		this.type = type;
		this.durationInYears = durationInYears;
		this.minLoanAmount = minLoanAmount;
		this.maxLoanAmount = maxLoanAmount;
		this.rateOfInterest = rateOfInterest;
		this.proofsRequired = proofsRequired;
	}
	
	//Getters and Setters
	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getDurationInYears() {
		return durationInYears;
	}

	public void setDurationInYears(int durationInYears) {
		this.durationInYears = durationInYears;
	}

	public double getMinLoanAmount() {
		return minLoanAmount;
	}

	public void setMinLoanAmount(double minLoanAmount) {
		this.minLoanAmount = minLoanAmount;
	}

	public double getMaxLoanAmount() {
		return maxLoanAmount;
	}

	public void setMaxLoanAmount(double maxLoanAmount) {
		this.maxLoanAmount = maxLoanAmount;
	}

	public double getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	public String getProofsRequired() {
		return proofsRequired;
	}

	public void setProofsRequired(String proofsRequired) {
		this.proofsRequired = proofsRequired;
	}

	//Generate to string
	@Override
	public String toString() {
		return "LoanProgramsOffered [programName=" + programName + ", description=" + description + ", type=" + type
				+ ", durationInYears=" + durationInYears + ", minLoanAmount=" + minLoanAmount + ", maxLoanAmount="
				+ maxLoanAmount + ", rateOfInterest=" + rateOfInterest + ", proofsRequired=" + proofsRequired + "]";
	}	
	
}
