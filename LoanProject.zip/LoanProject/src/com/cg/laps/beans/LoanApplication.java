package com.cg.laps.beans;

import java.time.LocalDate;

public class LoanApplication {
	
	long applicationId;
	LocalDate applicationDate;
	String loanProgram;
	double amountOfLoan;
	String addressOfProperty;
	double annualFamilyIncome;
	String documentProofsAvailable;
	String guaranteeCover;
	double marketValueofGuaranteeCover;
	String status;
	LocalDate dateOfInterview;

	//default constructor
	public LoanApplication() {
		// TODO Auto-generated constructor stub
	}

	//Parameterized Constructor
	public LoanApplication(long applicationId, LocalDate applicationDate, String loanProgram, double amountOfLoan,
			String addressOfProperty, double annualFamilyIncome, String documentProofsAvailable, String guaranteeCover,
			double marketValueofGuaranteeCover, String status, LocalDate dateOfInterview) {
		super();
		this.applicationId = applicationId;
		this.applicationDate = applicationDate;
		this.loanProgram = loanProgram;
		this.amountOfLoan = amountOfLoan;
		this.addressOfProperty = addressOfProperty;
		this.annualFamilyIncome = annualFamilyIncome;
		this.documentProofsAvailable = documentProofsAvailable;
		this.guaranteeCover = guaranteeCover;
		this.marketValueofGuaranteeCover = marketValueofGuaranteeCover;
		this.status = status;
		this.dateOfInterview = dateOfInterview;
	}

	//Getters and Setters
	public long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

	public LocalDate getApplicationDate() {
		return applicationDate;
	}

	public void setApplicationDate(LocalDate applicationDate) {
		this.applicationDate = applicationDate;
	}

	public String getLoanProgram() {
		return loanProgram;
	}

	public void setLoanProgram(String loanProgram) {
		this.loanProgram = loanProgram;
	}

	public double getAmountOfLoan() {
		return amountOfLoan;
	}

	public void setAmountOfLoan(double amountOfLoan) {
		this.amountOfLoan = amountOfLoan;
	}

	public String getAddressOfProperty() {
		return addressOfProperty;
	}

	public void setAddressOfProperty(String addressOfProperty) {
		this.addressOfProperty = addressOfProperty;
	}

	public double getAnnualFamilyIncome() {
		return annualFamilyIncome;
	}

	public void setAnnualFamilyIncome(double annualFamilyIncome) {
		this.annualFamilyIncome = annualFamilyIncome;
	}

	public String getDocumentProofsAvailable() {
		return documentProofsAvailable;
	}

	public void setDocumentProofsAvailable(String documentProofsAvailable) {
		this.documentProofsAvailable = documentProofsAvailable;
	}

	public String getGuaranteeCover() {
		return guaranteeCover;
	}

	public void setGuaranteeCover(String guaranteeCover) {
		this.guaranteeCover = guaranteeCover;
	}

	public double getMarketValueofGuaranteeCover() {
		return marketValueofGuaranteeCover;
	}

	public void setMarketValueofGuaranteeCover(double marketValueofGuaranteeCover) {
		this.marketValueofGuaranteeCover = marketValueofGuaranteeCover;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDate getDateOfInterview() {
		return dateOfInterview;
	}

	public void setDateOfInterview(LocalDate dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}

	//To String Method
	@Override
	public String toString() {
		return "LoanApplication [applicationId=" + applicationId + ", applicationDate=" + applicationDate
				+ ", loanProgram=" + loanProgram + ", amountOfLoan=" + amountOfLoan + ", addressOfProperty="
				+ addressOfProperty + ", annualFamilyIncome=" + annualFamilyIncome + ", documentProofsAvailable="
				+ documentProofsAvailable + ", guaranteeCover=" + guaranteeCover + ", marketValueofGuaranteeCover="
				+ marketValueofGuaranteeCover + ", status=" + status + ", dateOfInterview=" + dateOfInterview + "]";
	}		
	
}
